@extends('layout.app')

@section('title', 'About Prodamas')

@section('content')

@endsection
